###
# Load the package
###
library("KBAC")
?KbacTest

casectrl.dat <- read.table("phengen_recode.dat", skip = 1)

###
# Set parameters and use the KbacTest() function to obtain p-value
###
alpha <- 0.05
num.permutation <- 3000
quiet <- 1
alternative <- 1
maf.upper.bound <- 0.05
kbac.pvalue <- KbacTest(casectrl.dat, alpha, num.permutation, quiet, maf.upper.bound, alternative)
print(kbac.pvalue)

###
# To evaluate test at small alpha we need huge number of permutations. Adaptive approach is thus necessary.
###
kbac.pvalue <- KbacTest(casectrl.dat, 0.00001, 1000000, quiet, maf.upper.bound, alternative)
print(kbac.pvalue)

###
# Not using adaptive p-value calculation; will take long time
###
kbac.pvalue <- KbacTest(casectrl.dat, 9, 1000000, quiet, maf.upper.bound, alternative)
print(kbac.pvalue)
